import os
import sys
import optparse

#import some python modules from the SUMO_HOME/tools dir
if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    sys.path.append(tools)
else:
    sys.exit("declare environment variable 'SUMO_HOME'")

from sumolib import checkBinary   #checks for binary environment vars
import traci

def get_options():
    opt_parser = optparse.OptionParser()
    opt_parser.add_option("--nogui", action="store_true", default=False,
                         help="run the commandline version of sumo")
    options, args = opt_parser.parse_args()
    return options

##Temporary class for measuring CO2 emissions and fuel consumption 
class Car:
    def __init__(self, id):
        self.id = id
        self.CO2emission = 0
        self.FuelConsumption = 0
        
    def increaseCO2(self, emission, time):
        self.CO2emission += emission*time
        
    def increaseFuelConsumption(self, consumption, time):
        self.FuelConsumption += consumption*time
        
listOfCars = []
for x in range(10):
    listOfCars.append(Car("veh"+str(x)))
    
#-----------------------------------    

#control loop for TraCI
def run():    
    step = 0
    timeNew = traci.simulation.getTime()
    timeOld = 0
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        
        #make all cars move in lane 0 with low following distance
        
        currCarIdx = 0
        maxNumOfCars = 9
        arrivedCars = traci.simulation.getArrivedIDList()
        maxSpeed = 10
        
        while currCarIdx <= maxNumOfCars:
            currCar = "veh"+str(currCarIdx)
            if(currCar not in arrivedCars):
                traci.vehicle.changeLane(currCar, 2, 10) #carID, toLane, duration
                traci.vehicle.setSpeed(currCar, maxSpeed)
                #traci.vehicle.setMinGap("veh"+str(currCar), 0.01)    #sets minimum following distance in meters
                traci.vehicle.setTau(currCar, 0.01)    #sets minimum following distance in seconds
                maxSpeed += 5
            currCarIdx += 1
        
        
        #increase emission values        
        while currCarIdx <= maxNumOfCars:
            currChar = "veh"+str(currCarIdx)
            if(currCar not in arrivedCars):
                stepLength = timeNew-timeOld
                emissionCO2InStep = traci.vehicle.getCO2Emission(currCar)
                listOfCars[currCarIdx].increaseCO2(emissionCO2InStep, stepLength)
                consumptionInStep = traci.vehicle.getFuelConsumption(currCar)
                listOfCars[currCarIdx].increaseFuelConsumption(consumptionInStep, stepLength)
            currCarIdx+=1
            
                
        step += 1
        timeOld = timeNew
        timeNew = traci.simulation.getTime()    #get time after simulation step
        
    #traci.console()
    sys.stdout.flush()

#main entry point
if __name__ == "__main__":
    options = get_options()
    
    #check binary
    if options.nogui:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')
    
    #traci tarts sumo as a subprocess and then this scipt connects and runs
    traci.start([sumoBinary, "-c", "LongStraightHighway\LongStraightHighway.sumocfg",
                #"--tripinfo-output", "tripinfo.xml",    #writes out relevant data about car's trip
                #"--lanechange-output", "lanechanges.xml",   #writes out all lanechanges to the given file 
                "--lateral-resolution", "10.0",    #simulates sublanes
                "-d", "150",   #sets delay in gui
                "-b", "0",     #sets beginning simulation time
                "-e", "1000"   #sets ending simulation time
                ])
    #sublane and timestamp comes here
    
    run()